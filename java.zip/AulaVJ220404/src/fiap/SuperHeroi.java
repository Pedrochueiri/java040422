package fiap;

public class SuperHeroi {
	private String nome;
	private String idSecreto;
	private String poder;
	private String fraqueza;
	private String vilao;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIdSecreto() {
		return idSecreto;
	}

	public void setIdSecreto(String idSecreto) {
		this.idSecreto = idSecreto;
	}

	public String getPoder() {
		return poder;
	}

	public void setPoder(String poder) {
		this.poder = poder;
	}

	public String getFraqueza() {
		return fraqueza;
	}

	public void setFraqueza(String fraqueza) {
		this.fraqueza = fraqueza;
	}

	public String getVilao() {
		return vilao;
	}

	public void setVilao(String vilao) {
		this.vilao = vilao;
	}

}
