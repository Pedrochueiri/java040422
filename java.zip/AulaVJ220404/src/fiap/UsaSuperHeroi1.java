package fiap;

import java.util.Scanner;

public class UsaSuperHeroi1 {
	public static void main(String[] args) {
		SuperHeroi super1 = new SuperHeroi();
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite seu nome:");
		super1.setNome(scan.next());
		System.out.println("Digite seu idSecreto:");
		super1.setIdSecreto(scan.next());
		System.out.println("Digite seu Vilao:");
		super1.setVilao(scan.next());
		System.out.println("Digite seu Poder:");
		super1.setPoder(scan.next());
		System.out.println("Digite sua fraquesa:");
		super1.setFraqueza(scan.next());
		
		System.out.println("Nome: "+super1.getNome()+ "\nId Secreto: "+ super1.getIdSecreto()+"\nFraqueza: " + super1.getFraqueza()+"\nPoder: "+ super1.getPoder()+ "\nVilao: " +super1.getVilao());
		
	}
}
