package fiap;

public class UsaPessoa {
	public static void main(String[] args) {
		//declarando e instanciado um objeto da classe Pessoa 
		Pessoa pessoa1 = new Pessoa();
		Pessoa pessoa2 = new Pessoa();
		Pessoa pessoa3 = new Pessoa();
		
		//definindo nome e idade 
		pessoa1.setNome("Lucas Guerra ");
		pessoa1.setIdade(69);
		
		//Exibindo nome e idade 
		System.out.println("Nome: " + pessoa1.getNome());
		System.out.println("Idade: "+ pessoa1.getIdade());
		
		
		pessoa1.setNome("Pedro Chueiri");
		pessoa1.setIdade(999);
		System.out.println("Nome: "+ pessoa2.getNome()+"\nIdade: "+pessoa2.getIdade());
		
		System.out.println("Nome: " + pessoa3.getNome());
		System.out.println("Idade: "+ pessoa3.getIdade());
		
		
		pessoa1.setNome("Pedro Chueiri");
		pessoa1.setIdade(999);
		System.out.println("Nome: "+ pessoa3.getNome()+"\nIdade: "+pessoa3.getIdade());
	}
}
