package fiap;

public class UsaSuperHeroi {
	public static void main(String[] args) {
		SuperHeroi super1 = new SuperHeroi();
		
		super1.setFraqueza("Vilao");
		super1.setNome("Lucas");
		super1.setIdSecreto("Super Mente");
		super1.setPoder("Ele mesmo");
		super1.setVilao("Babu99");
		
		System.out.println("Nome: "+super1.getNome()+ "\nId Secreto: "+ super1.getIdSecreto()+"\nFraqueza: " + super1.getFraqueza()+"\nPoder: "+ super1.getPoder()+ "\nVilao: " +super1.getVilao());
		
	}
}
